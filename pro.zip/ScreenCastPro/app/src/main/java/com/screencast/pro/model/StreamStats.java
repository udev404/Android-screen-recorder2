package com.screencast.pro.model;

public class StreamStats {
    public long   framesEncoded;
    public int    bitrateBps;
    public int    viewerCount;
    public long   durationMs;
    public long   bytesTotal;

    public String getBitrateFormatted() {
        if (bitrateBps >= 1_000_000) return String.format("%.1f Mbps", bitrateBps / 1_000_000f);
        if (bitrateBps >= 1_000)     return String.format("%.0f Kbps", bitrateBps / 1_000f);
        return bitrateBps + " bps";
    }

    public String getDurationFormatted() {
        long s = durationMs / 1000;
        return String.format("%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60);
    }
}
