package com.screencast.pro.model;

public class StreamConfig {
    public int width       = 1080;
    public int height      = 1920;
    public int fps         = 60;
    public int bitrateMbps = 8;
    public String codec    = "video/avc";   // H.264
    public boolean audioEnabled = true;
    public int port        = 9339;

    public int getBitrateBps() { return bitrateMbps * 1_000_000; }

    public static StreamConfig defaultConfig() { return new StreamConfig(); }

    public static StreamConfig highQuality() {
        StreamConfig c = new StreamConfig();
        c.width = 1080; c.height = 1920; c.fps = 60; c.bitrateMbps = 12;
        c.codec = "video/hevc";
        return c;
    }

    public static StreamConfig lowLatency() {
        StreamConfig c = new StreamConfig();
        c.width = 720; c.height = 1280; c.fps = 30; c.bitrateMbps = 4;
        return c;
    }
}
