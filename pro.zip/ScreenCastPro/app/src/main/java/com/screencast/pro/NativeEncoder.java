package com.screencast.pro;

import android.view.Surface;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * JNI bridge to the C++ NativeEncoder.
 * Handles H.264/H.265 encoding via Android NDK MediaCodec.
 */
public class NativeEncoder {

    static {
        System.loadLibrary("screencast_native");
    }

    // ── Callback interface ────────────────────────────────────────────────────

    public interface FrameCallback {
        /**
         * Called from native encoder thread with each encoded NAL unit.
         *
         * @param data        Raw NAL unit bytes
         * @param timestampUs Presentation timestamp in microseconds
         * @param isKeyframe  Whether this NAL is an IDR (keyframe)
         */
        void onFrameEncoded(@NonNull byte[] data, long timestampUs, boolean isKeyframe);
    }

    // ── Config ────────────────────────────────────────────────────────────────

    public static final class Config {
        public int    width         = 1080;
        public int    height        = 1920;
        public int    fps           = 60;
        public int    bitrateBps    = 8_000_000;
        public String codec         = "video/avc";   // or "video/hevc"

        public Config() {}

        public Config(int w, int h, int fps, int bps, String mime) {
            this.width      = w;
            this.height     = h;
            this.fps        = fps;
            this.bitrateBps = bps;
            this.codec      = mime;
        }
    }

    // ── State ─────────────────────────────────────────────────────────────────

    private boolean initialized = false;

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Initialize the native encoder.
     *
     * @return true on success
     */
    public boolean init(@NonNull Config cfg, @Nullable FrameCallback callback) {
        initialized = nativeInit(
            cfg.width, cfg.height, cfg.fps, cfg.bitrateBps, cfg.codec,
            callback);
        return initialized;
    }

    /**
     * Returns the Surface that MediaProjection should render into.
     * Must be called after {@link #init}.
     */
    @Nullable
    public Surface getInputSurface() {
        if (!initialized) return null;
        return nativeGetInputSurface();
    }

    /** Request end of stream; encoder drains remaining frames then stops. */
    public void signalEndOfStream() {
        if (initialized) nativeSignalEOS();
    }

    /** Release all native resources. */
    public void release() {
        if (initialized) {
            nativeRelease();
            initialized = false;
        }
    }

    public long getFramesEncoded() { return nativeGetFramesEncoded(); }
    public int  getCurrentBitrateBps() { return nativeGetCurrentBitrate(); }

    // ── Native declarations ───────────────────────────────────────────────────

    private native boolean init(int w, int h, int fps, int bps, String mime);
    private native boolean nativeInit(int w, int h, int fps, int bps,
                                      String mime, Object callback);
    private native Surface nativeGetInputSurface();
    private native void    nativeSignalEOS();
    private native void    nativeRelease();
    private native long    nativeGetFramesEncoded();
    private native int     nativeGetCurrentBitrate();
}
