package com.screencast.pro;

import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.nanohttpd.protocols.http.IHTTPSession;
import org.nanohttpd.protocols.http.NanoHTTPD;
import org.nanohttpd.protocols.http.response.Response;
import org.nanohttpd.protocols.http.response.Status;
import org.nanohttpd.protocols.websockets.CloseCode;
import org.nanohttpd.protocols.websockets.NanoWSD;
import org.nanohttpd.protocols.websockets.WebSocket;
import org.nanohttpd.protocols.websockets.WebSocketFrame;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Combined HTTP + WebSocket signaling server running on port 9339.
 *
 * HTTP GET  /        → HTML viewer page
 * HTTP GET  /health  → JSON health check
 * WS        /signal  → WebRTC signaling (offer / answer / ICE)
 */
public class SignalingServer extends NanoWSD {

    private static final String TAG  = "SignalingServer";
    public  static final int    PORT = 9339;

    public interface SignalingListener {
        void onViewerConnected(String peerId);
        void onViewerDisconnected(String peerId);
        void onOfferReceived(String peerId, String sdp);
        void onIceCandidateReceived(String peerId, String candidate, String sdpMid, int sdpMLineIndex);
    }

    private final List<ScreenWebSocket> viewers = new CopyOnWriteArrayList<>();
    private SignalingListener listener;
    private final Gson gson = new Gson();

    private volatile String localAnswer = null;   // SDP answer from WebRTCManager

    public SignalingServer() {
        super(PORT);
    }

    public void setListener(SignalingListener l) { this.listener = l; }

    /** Call when WebRTCManager has produced an SDP answer for a peer. */
    public void sendAnswer(String peerId, String sdp) {
        localAnswer = sdp;
        for (ScreenWebSocket ws : viewers) {
            if (peerId.equals(ws.peerId)) {
                JsonObject msg = new JsonObject();
                msg.addProperty("type", "answer");
                msg.addProperty("sdp", sdp);
                try { ws.send(gson.toJson(msg)); } catch (IOException e) { Log.e(TAG, "sendAnswer", e); }
                break;
            }
        }
    }

    /** Send an ICE candidate to a specific viewer peer. */
    public void sendIceCandidate(String peerId, String candidate, String sdpMid, int sdpMLineIndex) {
        for (ScreenWebSocket ws : viewers) {
            if (peerId.equals(ws.peerId)) {
                JsonObject msg = new JsonObject();
                msg.addProperty("type", "ice");
                msg.addProperty("candidate", candidate);
                msg.addProperty("sdpMid", sdpMid);
                msg.addProperty("sdpMLineIndex", sdpMLineIndex);
                try { ws.send(gson.toJson(msg)); } catch (IOException e) { Log.e(TAG, "sendIce", e); }
                break;
            }
        }
    }

    public int getViewerCount() { return viewers.size(); }

    // ── NanoWSD: handle HTTP vs WS upgrade ───────────────────────────────────

    @Override
    protected WebSocket openWebSocket(IHTTPSession session) {
        ScreenWebSocket ws = new ScreenWebSocket(session);
        viewers.add(ws);
        return ws;
    }

    @Override
    public Response serveHttp(IHTTPSession session) {
        String uri = session.getUri();

        if ("/health".equals(uri)) {
            JsonObject json = new JsonObject();
            json.addProperty("status", "ok");
            json.addProperty("viewers", viewers.size());
            return Response.newFixedLengthResponse(Status.OK, "application/json", gson.toJson(json));
        }

        // Serve the viewer HTML page
        return Response.newFixedLengthResponse(Status.OK, "text/html; charset=UTF-8", viewerHtml());
    }

    // ── WebSocket implementation ──────────────────────────────────────────────

    private class ScreenWebSocket extends WebSocket {
        final String peerId = java.util.UUID.randomUUID().toString().substring(0, 8);

        ScreenWebSocket(IHTTPSession session) { super(session); }

        @Override
        protected void onOpen() {
            Log.i(TAG, "WS opened peerId=" + peerId);
            // Send greeting
            JsonObject msg = new JsonObject();
            msg.addProperty("type", "hello");
            msg.addProperty("peerId", peerId);
            try { send(gson.toJson(msg)); } catch (IOException e) { Log.e(TAG, "onOpen", e); }
            if (listener != null) listener.onViewerConnected(peerId);
        }

        @Override
        protected void onClose(CloseCode code, String reason, boolean initiatedByRemote) {
            Log.i(TAG, "WS closed peerId=" + peerId + " reason=" + reason);
            viewers.remove(this);
            if (listener != null) listener.onViewerDisconnected(peerId);
        }

        @Override
        protected void onMessage(WebSocketFrame frame) {
            String text = frame.getTextPayload();
            Log.d(TAG, "WS msg peerId=" + peerId + ": " + text.substring(0, Math.min(120, text.length())));
            try {
                JsonObject json = JsonParser.parseString(text).getAsJsonObject();
                String type = json.get("type").getAsString();

                switch (type) {
                    case "offer":
                        if (listener != null)
                            listener.onOfferReceived(peerId, json.get("sdp").getAsString());
                        break;
                    case "ice":
                        if (listener != null)
                            listener.onIceCandidateReceived(
                                peerId,
                                json.get("candidate").getAsString(),
                                json.has("sdpMid") ? json.get("sdpMid").getAsString() : "0",
                                json.has("sdpMLineIndex") ? json.get("sdpMLineIndex").getAsInt() : 0);
                        break;
                }
            } catch (Exception e) {
                Log.e(TAG, "Message parse error", e);
            }
        }

        @Override protected void onPong(WebSocketFrame pong) {}
        @Override protected void onException(IOException e) {
            Log.e(TAG, "WS exception peerId=" + peerId, e);
        }
    }

    // ── Viewer HTML Page ─────────────────────────────────────────────────────

    private String viewerHtml() {
        return "<!DOCTYPE html>\n" +
"<html lang='en'>\n" +
"<head>\n" +
"<meta charset='UTF-8'>\n" +
"<meta name='viewport' content='width=device-width, initial-scale=1'>\n" +
"<title>ScreenCast Pro — Live</title>\n" +
"<style>\n" +
"  :root{--bg:#060608;--accent:#00f5c4;--red:#ff3b5c;--card:rgba(255,255,255,0.04)}\n" +
"  *{margin:0;padding:0;box-sizing:border-box}\n" +
"  body{background:var(--bg);color:#fff;font-family:'SF Pro Display',system-ui,sans-serif;\n" +
"       min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center}\n" +
"  .badge{display:inline-flex;align-items:center;gap:6px;background:var(--red);\n" +
"         padding:4px 12px;border-radius:20px;font-size:11px;font-weight:700;\n" +
"         letter-spacing:.1em;text-transform:uppercase;margin-bottom:16px}\n" +
"  .badge::before{content:'';width:8px;height:8px;border-radius:50%;background:#fff;\n" +
"                 animation:pulse 1.2s infinite}\n" +
"  @keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}}\n" +
"  video{width:min(100vw,720px);aspect-ratio:9/16;background:#111;border-radius:12px;\n" +
"        object-fit:contain;box-shadow:0 0 60px rgba(0,245,196,.15)}\n" +
"  #status{margin-top:12px;font-size:13px;color:rgba(255,255,255,.5)}\n" +
"  #stats{display:flex;gap:20px;margin-top:12px;font-size:12px;color:var(--accent)}\n" +
"  .stat label{display:block;font-size:10px;opacity:.5;margin-bottom:2px}\n" +
"</style>\n" +
"</head>\n" +
"<body>\n" +
"<div class='badge'>🔴 Live Stream</div>\n" +
"<video id='v' autoplay playsinline muted></video>\n" +
"<div id='status'>Connecting…</div>\n" +
"<div id='stats'>\n" +
"  <div class='stat'><label>Resolution</label><span id='res'>—</span></div>\n" +
"  <div class='stat'><label>FPS</label><span id='fps'>—</span></div>\n" +
"  <div class='stat'><label>Bytes Rx</label><span id='byt'>0</span></div>\n" +
"</div>\n" +
"<script>\n" +
"const ws = new WebSocket(`ws://${location.host}/signal`);\n" +
"const pc = new RTCPeerConnection({iceServers:[{urls:'stun:stun.l.google.com:19302'}]});\n" +
"let byteCount=0,frameCount=0,lastTime=performance.now();\n" +
"pc.ontrack = e=>{\n" +
"  document.getElementById('v').srcObject=e.streams[0];\n" +
"  document.getElementById('status').textContent='✅  Connected';\n" +
"  const track=e.track;\n" +
"  if(track.kind==='video'){\n" +
"    setInterval(async()=>{\n" +
"      const s=await pc.getStats();\n" +
"      s.forEach(r=>{\n" +
"        if(r.type==='inbound-rtp'&&r.kind==='video'){\n" +
"          const now=performance.now();\n" +
"          const dt=(now-lastTime)/1000;\n" +
"          const frames=r.framesDecoded-frameCount;\n" +
"          document.getElementById('fps').textContent=Math.round(frames/dt);\n" +
"          document.getElementById('byt').textContent=formatBytes(r.bytesReceived);\n" +
"          if(r.frameWidth)document.getElementById('res').textContent=r.frameWidth+'×'+r.frameHeight;\n" +
"          byteCount=r.bytesReceived;frameCount=r.framesDecoded;lastTime=now;\n" +
"        }\n" +
"      });\n" +
"    },1000);\n" +
"  }\n" +
"};\n" +
"pc.onicecandidate = e=>{\n" +
"  if(e.candidate) ws.send(JSON.stringify({type:'ice',candidate:e.candidate.candidate,\n" +
"    sdpMid:e.candidate.sdpMid,sdpMLineIndex:e.candidate.sdpMLineIndex}));\n" +
"};\n" +
"ws.onmessage = async e=>{\n" +
"  const msg=JSON.parse(e.data);\n" +
"  if(msg.type==='offer'){\n" +
"    await pc.setRemoteDescription({type:'offer',sdp:msg.sdp});\n" +
"    const ans=await pc.createAnswer();\n" +
"    await pc.setLocalDescription(ans);\n" +
"    ws.send(JSON.stringify({type:'offer',sdp:msg.sdp}));\n" +
"    // Note: server sends offer, browser answers\n" +
"  } else if(msg.type==='answer'){\n" +
"    // Already handled\n" +
"  } else if(msg.type==='ice'){\n" +
"    try{await pc.addIceCandidate({candidate:msg.candidate,sdpMid:msg.sdpMid,\n" +
"      sdpMLineIndex:msg.sdpMLineIndex});}catch(e){}\n" +
"  } else if(msg.type==='hello'){\n" +
"    document.getElementById('status').textContent='🔄 Negotiating WebRTC…';\n" +
"    // Create offer from browser side too for cross-compat\n" +
"    pc.addTransceiver('video',{direction:'recvonly'});\n" +
"    pc.addTransceiver('audio',{direction:'recvonly'});\n" +
"    const offer=await pc.createOffer();\n" +
"    await pc.setLocalDescription(offer);\n" +
"    ws.send(JSON.stringify({type:'offer',sdp:offer.sdp}));\n" +
"  }\n" +
"};\n" +
"ws.onclose=()=>document.getElementById('status').textContent='❌ Disconnected';\n" +
"function formatBytes(b){\n" +
"  if(b<1024)return b+'B';\n" +
"  if(b<1048576)return(b/1024).toFixed(1)+'KB';\n" +
"  return(b/1048576).toFixed(1)+'MB';\n" +
"}\n" +
"</script>\n" +
"</body></html>";
    }
}
