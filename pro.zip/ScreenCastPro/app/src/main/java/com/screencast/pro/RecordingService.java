package com.screencast.pro;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import android.view.Surface;
import com.screencast.pro.utils.NetworkUtils;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import org.webrtc.ScreenCapturerAndroid;
import org.webrtc.VideoCapturer;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Foreground service that:
 * 1. Captures the screen via MediaProjection
 * 2. Streams via WebRTC to browser viewers on port 9339
 * 3. Hosts the HTTP + WebSocket signaling server (SignalingServer)
 */
public class RecordingService extends Service {

    private static final String TAG             = "RecordingService";
    public  static final String EXTRA_RESULT_CODE = "result_code";
    public  static final String EXTRA_RESULT_DATA  = "result_data";
    private static final String CHANNEL_ID      = "screencast_channel";
    private static final int    NOTIF_ID        = 1001;

    // ── Binder ────────────────────────────────────────────────────────────────

    public class LocalBinder extends Binder {
        public RecordingService getService() { return RecordingService.this; }
    }
    private final IBinder binder = new LocalBinder();

    // ── State ────────────────────────────────────────────────────────────────

    private MediaProjectionManager projectionManager;
    private MediaProjection mediaProjection;
    private VirtualDisplay  virtualDisplay;

    private WebRTCManager   webRTCManager;
    private SignalingServer signalingServer;
    private NativeEncoder   nativeEncoder;

    private final AtomicBoolean streaming = new AtomicBoolean(false);
    private final Handler handler = new Handler(Looper.getMainLooper());

    // Listener for UI updates
    public interface ServiceListener {
        void onStreamingStarted(String streamUrl);
        void onStreamingStopped();
        void onViewerCountChanged(int count);
        void onStats(long framesEncoded, int bitrateBps);
        void onError(String msg);
    }
    private volatile ServiceListener serviceListener;

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    @Override
    public void onCreate() {
        super.onCreate();
        projectionManager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        createNotificationChannel();
        Log.i(TAG, "RecordingService created");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(NOTIF_ID, buildNotification("Preparing stream…"));

        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
        Intent resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA);

        if (resultCode == 0 || resultData == null) {
            Log.e(TAG, "Missing MediaProjection result");
            stopSelf();
            return START_NOT_STICKY;
        }

        startStreaming(resultCode, resultData);
        return START_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) { return binder; }

    @Override
    public void onDestroy() {
        stopStreaming();
        super.onDestroy();
        Log.i(TAG, "RecordingService destroyed");
    }

    // ── Public API ────────────────────────────────────────────────────────────

    public void setListener(ServiceListener l) { this.serviceListener = l; }
    public boolean isStreaming() { return streaming.get(); }

    public void stopStreaming() {
        if (!streaming.compareAndSet(true, false)) return;

        Log.i(TAG, "Stopping stream…");

        if (signalingServer != null) {
            signalingServer.stop();
            signalingServer = null;
        }

        if (webRTCManager != null) {
            webRTCManager.release();
            webRTCManager = null;
        }

        if (virtualDisplay != null) {
            virtualDisplay.release();
            virtualDisplay = null;
        }

        if (mediaProjection != null) {
            mediaProjection.stop();
            mediaProjection = null;
        }

        if (nativeEncoder != null) {
            nativeEncoder.signalEndOfStream();
            nativeEncoder.release();
            nativeEncoder = null;
        }

        handler.post(() -> {
            if (serviceListener != null) serviceListener.onStreamingStopped();
        });

        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    // ── Streaming setup ───────────────────────────────────────────────────────

    private void startStreaming(int resultCode, Intent resultData) {
        try {
            // 1. Obtain MediaProjection
            mediaProjection = projectionManager.getMediaProjection(resultCode, resultData);
            if (mediaProjection == null) throw new IllegalStateException("MediaProjection null");

            // 2. Register stop callback
            mediaProjection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() {
                    Log.w(TAG, "MediaProjection stopped externally");
                    stopStreaming();
                }
            }, handler);

            // 3. Start WebRTC (with ScreenCapturerAndroid)
            VideoCapturer capturer = new ScreenCapturerAndroid(resultData, new MediaProjection.Callback() {
                @Override public void onStop() { stopStreaming(); }
            });

            webRTCManager = new WebRTCManager(this);
            webRTCManager.setCallback(new WebRTCManager.Callback() {
                @Override public void onLocalSdp(String peerId, org.webrtc.SessionDescription sdp) {
                    if (signalingServer != null)
                        signalingServer.sendAnswer(peerId, sdp.description);
                }
                @Override public void onIceCandidate(String peerId, org.webrtc.IceCandidate c) {
                    if (signalingServer != null)
                        signalingServer.sendIceCandidate(peerId, c.sdp, c.sdpMid, c.sdpMLineIndex);
                }
                @Override public void onError(String msg) {
                    Log.e(TAG, "WebRTC error: " + msg);
                }
            });
            webRTCManager.init(capturer);

            // 4. Start signaling server on port 9339
            signalingServer = new SignalingServer();
            signalingServer.setListener(new SignalingServer.SignalingListener() {
                @Override public void onViewerConnected(String peerId) {
                    Log.i(TAG, "Viewer connected: " + peerId);
                    handler.post(() -> {
                        if (serviceListener != null)
                            serviceListener.onViewerCountChanged(webRTCManager != null ? webRTCManager.getViewerCount() + 1 : 0);
                    });
                }
                @Override public void onViewerDisconnected(String peerId) {
                    webRTCManager.removeViewer(peerId);
                    handler.post(() -> {
                        if (serviceListener != null)
                            serviceListener.onViewerCountChanged(webRTCManager != null ? webRTCManager.getViewerCount() : 0);
                    });
                }
                @Override public void onOfferReceived(String peerId, String sdp) {
                    webRTCManager.handleOffer(peerId, sdp);
                }
                @Override public void onIceCandidateReceived(String peerId, String candidate, String sdpMid, int sdpMLineIndex) {
                    webRTCManager.addIceCandidate(peerId, candidate, sdpMid, sdpMLineIndex);
                }
            });
            signalingServer.start();

            // 5. Get device IP for the stream URL
            String ip = NetworkUtils.getLocalIpAddress();
            String streamUrl = "http://" + ip + ":" + SignalingServer.PORT;

            streaming.set(true);

            // Update notification
            updateNotification("🔴 Live — " + streamUrl);

            handler.post(() -> {
                if (serviceListener != null) serviceListener.onStreamingStarted(streamUrl);
            });

            // 6. Stats reporter
            handler.postDelayed(statsRunnable, 1000);

            Log.i(TAG, "Streaming started: " + streamUrl);

        } catch (IOException e) {
            Log.e(TAG, "Failed to start signaling server", e);
            if (serviceListener != null) serviceListener.onError("Server start failed: " + e.getMessage());
            stopSelf();
        } catch (Exception e) {
            Log.e(TAG, "Failed to start streaming", e);
            if (serviceListener != null) serviceListener.onError(e.getMessage());
            stopSelf();
        }
    }

    // ── Stats runnable ────────────────────────────────────────────────────────

    private final Runnable statsRunnable = new Runnable() {
        @Override public void run() {
            if (!streaming.get()) return;
            if (serviceListener != null && nativeEncoder != null) {
                serviceListener.onStats(
                    nativeEncoder.getFramesEncoded(),
                    nativeEncoder.getCurrentBitrateBps());
            }
            handler.postDelayed(this, 1000);
        }
    };

    // ── Notification ──────────────────────────────────────────────────────────

    private void createNotificationChannel() {
        NotificationChannel ch = new NotificationChannel(
            CHANNEL_ID, "Screen Streaming",
            NotificationManager.IMPORTANCE_LOW);
        ch.setDescription("ScreenCast Pro live stream");
        ch.setLightColor(Color.GREEN);
        ch.setShowBadge(false);
        getSystemService(NotificationManager.class).createNotificationChannel(ch);
    }

    private Notification buildNotification(String text) {
        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, openIntent,
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Intent stopIntent = new Intent(this, RecordingService.class);
        stopIntent.setAction("STOP_STREAM");
        PendingIntent stopPi = PendingIntent.getService(this, 1, stopIntent,
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("ScreenCast Pro")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentIntent(pi)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stopPi)
            .setOngoing(true)
            .setShowWhen(true)
            .setWhen(System.currentTimeMillis())
            .setUsesChronometer(true)
            .build();
    }

    private void updateNotification(String text) {
        Notification n = buildNotification(text);
        getSystemService(NotificationManager.class).notify(NOTIF_ID, n);
    }
}
