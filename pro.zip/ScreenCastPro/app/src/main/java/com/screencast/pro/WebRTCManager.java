package com.screencast.pro;

import android.content.Context;
import android.util.Log;

import org.webrtc.AudioSource;
import org.webrtc.AudioTrack;
import org.webrtc.DataChannel;
import org.webrtc.DefaultVideoDecoderFactory;
import org.webrtc.DefaultVideoEncoderFactory;
import org.webrtc.EglBase;
import org.webrtc.IceCandidate;
import org.webrtc.MediaConstraints;
import org.webrtc.MediaStream;
import org.webrtc.PeerConnection;
import org.webrtc.PeerConnectionFactory;
import org.webrtc.RtpReceiver;
import org.webrtc.RtpSender;
import org.webrtc.SdpObserver;
import org.webrtc.SessionDescription;
import org.webrtc.SurfaceTextureHelper;
import org.webrtc.VideoCapturer;
import org.webrtc.VideoSource;
import org.webrtc.VideoTrack;
import org.webrtc.audio.JavaAudioDeviceModule;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages WebRTC PeerConnections for multi-viewer screen streaming.
 */
public class WebRTCManager {

    private static final String TAG = "WebRTCManager";

    public interface Callback {
        void onLocalSdp(String peerId, SessionDescription sdp);
        void onIceCandidate(String peerId, IceCandidate candidate);
        void onError(String msg);
    }

    // ── State ────────────────────────────────────────────────────────────────

    private final Context ctx;
    private Callback callback;
    private EglBase eglBase;

    private PeerConnectionFactory factory;
    private VideoSource    videoSource;
    private VideoTrack     videoTrack;
    private AudioSource    audioSource;
    private AudioTrack     audioTrack;
    private VideoCapturer  screenCapturer;

    // peerId → PeerConnection
    private final Map<String, PeerConnection> peers = new ConcurrentHashMap<>();

    private boolean initialized = false;

    // ICE servers — STUN + optional TURN
    private static final List<PeerConnection.IceServer> ICE_SERVERS = List.of(
        PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
        PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer()
    );

    // ── Constructor ──────────────────────────────────────────────────────────

    public WebRTCManager(Context ctx) {
        this.ctx = ctx.getApplicationContext();
    }

    public void setCallback(Callback cb) { this.callback = cb; }

    // ── Init ─────────────────────────────────────────────────────────────────

    public void init(VideoCapturer capturer) {
        this.screenCapturer = capturer;

        eglBase = EglBase.create();

        PeerConnectionFactory.InitializationOptions initOpts =
            PeerConnectionFactory.InitializationOptions.builder(ctx)
                .setEnableInternalTracer(false)
                .createInitializationOptions();
        PeerConnectionFactory.initialize(initOpts);

        // Use hardware-accelerated encoder/decoder
        DefaultVideoEncoderFactory encFactory =
            new DefaultVideoEncoderFactory(eglBase.getEglBaseContext(), true, true);
        DefaultVideoDecoderFactory decFactory =
            new DefaultVideoDecoderFactory(eglBase.getEglBaseContext());

        PeerConnectionFactory.Options opts = new PeerConnectionFactory.Options();

        factory = PeerConnectionFactory.builder()
            .setOptions(opts)
            .setVideoEncoderFactory(encFactory)
            .setVideoDecoderFactory(decFactory)
            .setAudioDeviceModule(
                JavaAudioDeviceModule.builder(ctx)
                    .setUseHardwareAcousticEchoCanceler(true)
                    .setUseHardwareNoiseSuppressor(true)
                    .createAudioDeviceModule())
            .createPeerConnectionFactory();

        // Video track from screen capturer
        SurfaceTextureHelper helper = SurfaceTextureHelper.create(
            "CaptureThread", eglBase.getEglBaseContext());

        videoSource = factory.createVideoSource(capturer.isScreencast());
        capturer.initialize(helper, ctx, videoSource.getCapturerObserver());
        capturer.startCapture(1080, 1920, 60);

        videoTrack = factory.createVideoTrack("SCREEN_0", videoSource);
        videoTrack.setEnabled(true);

        // Audio track (microphone)
        MediaConstraints audioConstraints = new MediaConstraints();
        audioConstraints.mandatory.add(
            new MediaConstraints.KeyValuePair("echoCancellation", "true"));
        audioConstraints.mandatory.add(
            new MediaConstraints.KeyValuePair("noiseSuppression", "true"));
        audioConstraints.mandatory.add(
            new MediaConstraints.KeyValuePair("autoGainControl", "true"));

        audioSource = factory.createAudioSource(audioConstraints);
        audioTrack  = factory.createAudioTrack("AUDIO_0", audioSource);
        audioTrack.setEnabled(true);

        initialized = true;
        Log.i(TAG, "WebRTCManager initialized");
    }

    // ── Handle incoming SDP offer from a browser viewer ──────────────────────

    public void handleOffer(String peerId, String sdpStr) {
        if (!initialized) { Log.e(TAG, "Not initialized"); return; }

        PeerConnection pc = getOrCreatePeer(peerId);
        if (pc == null) return;

        SessionDescription offer = new SessionDescription(
            SessionDescription.Type.OFFER, sdpStr);

        pc.setRemoteDescription(new SimpleSdpObserver("setRemote:" + peerId) {
            @Override public void onSetSuccess() {
                super.onSetSuccess();
                // Create answer
                MediaConstraints constraints = new MediaConstraints();
                pc.createAnswer(new SimpleSdpObserver("createAnswer:" + peerId) {
                    @Override public void onCreateSuccess(SessionDescription sdp) {
                        super.onCreateSuccess(sdp);
                        pc.setLocalDescription(new SimpleSdpObserver("setLocal:" + peerId), sdp);
                        if (callback != null) callback.onLocalSdp(peerId, sdp);
                    }
                }, constraints);
            }
        }, offer);
    }

    /** Add ICE candidate from a remote viewer. */
    public void addIceCandidate(String peerId, String candidate, String sdpMid, int sdpMLineIndex) {
        PeerConnection pc = peers.get(peerId);
        if (pc == null) return;
        pc.addIceCandidate(new IceCandidate(sdpMid, sdpMLineIndex, candidate));
    }

    /** Remove a specific viewer's peer connection. */
    public void removeViewer(String peerId) {
        PeerConnection pc = peers.remove(peerId);
        if (pc != null) { pc.close(); }
    }

    public int getViewerCount() { return peers.size(); }

    // ── Cleanup ───────────────────────────────────────────────────────────────

    public void release() {
        if (screenCapturer != null) {
            try { screenCapturer.stopCapture(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }
        for (PeerConnection pc : peers.values()) pc.close();
        peers.clear();

        if (videoTrack != null) videoTrack.dispose();
        if (videoSource != null) videoSource.dispose();
        if (audioTrack != null) audioTrack.dispose();
        if (audioSource != null) audioSource.dispose();
        if (factory != null) factory.dispose();
        if (eglBase != null) eglBase.release();
        initialized = false;
        Log.i(TAG, "WebRTCManager released");
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private PeerConnection getOrCreatePeer(String peerId) {
        if (peers.containsKey(peerId)) return peers.get(peerId);

        PeerConnection.RTCConfiguration config = new PeerConnection.RTCConfiguration(ICE_SERVERS);
        config.sdpSemantics      = PeerConnection.SdpSemantics.UNIFIED_PLAN;
        config.bundlePolicy      = PeerConnection.BundlePolicy.MAXBUNDLE;
        config.rtcpMuxPolicy     = PeerConnection.RtcpMuxPolicy.REQUIRE;
        config.continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY;

        PeerConnection pc = factory.createPeerConnection(config, new PeerConnection.Observer() {
            @Override public void onIceCandidate(IceCandidate candidate) {
                if (callback != null) callback.onIceCandidate(peerId, candidate);
            }
            @Override public void onConnectionChange(PeerConnection.PeerConnectionState state) {
                Log.i(TAG, "Peer " + peerId + " state=" + state);
            }
            @Override public void onIceConnectionChange(PeerConnection.IceConnectionState s) {}
            @Override public void onSignalingChange(PeerConnection.SignalingState s) {}
            @Override public void onIceConnectionReceivingChange(boolean r) {}
            @Override public void onIceGatheringChange(PeerConnection.IceGatheringState s) {}
            @Override public void onIceCandidatesRemoved(IceCandidate[] c) {}
            @Override public void onAddStream(MediaStream s) {}
            @Override public void onRemoveStream(MediaStream s) {}
            @Override public void onDataChannel(DataChannel d) {}
            @Override public void onRenegotiationNeeded() {}
            @Override public void onAddTrack(RtpReceiver r, MediaStream[] s) {}
        });

        if (pc == null) {
            Log.e(TAG, "Failed to create PeerConnection for " + peerId);
            return null;
        }

        // Add local tracks
        List<String> streamIds = Collections.singletonList("SCREEN_STREAM");
        pc.addTrack(videoTrack, streamIds);
        pc.addTrack(audioTrack, streamIds);

        // Prefer H.264 for compatibility
        for (RtpSender sender : pc.getSenders()) {
            if (sender.track() != null && "video".equals(sender.track().kind())) {
                preferH264(sender);
            }
        }

        peers.put(peerId, pc);
        Log.i(TAG, "Created PeerConnection for " + peerId + ", total peers=" + peers.size());
        return pc;
    }

    private void preferH264(RtpSender sender) {
        try {
            org.webrtc.RtpParameters params = sender.getParameters();
            if (params == null) return;
            List<org.webrtc.RtpParameters.Codec> codecs = params.codecs;
            List<org.webrtc.RtpParameters.Codec> reordered = new ArrayList<>();
            for (org.webrtc.RtpParameters.Codec c : codecs)
                if ("H264".equalsIgnoreCase(c.name)) reordered.add(c);
            for (org.webrtc.RtpParameters.Codec c : codecs)
                if (!"H264".equalsIgnoreCase(c.name)) reordered.add(c);
            params.codecs = reordered;
            sender.setParameters(params);
        } catch (Exception e) {
            Log.w(TAG, "preferH264 failed", e);
        }
    }

    // ── SimpleSdpObserver ─────────────────────────────────────────────────────

    private static class SimpleSdpObserver implements SdpObserver {
        private final String tag;
        SimpleSdpObserver(String tag) { this.tag = tag; }
        @Override public void onCreateSuccess(SessionDescription sdp) {
            Log.d(TAG, tag + " onCreateSuccess type=" + sdp.type);
        }
        @Override public void onSetSuccess()    { Log.d(TAG, tag + " onSetSuccess"); }
        @Override public void onCreateFailure(String e) { Log.e(TAG, tag + " onCreateFailure: " + e); }
        @Override public void onSetFailure(String e)    { Log.e(TAG, tag + " onSetFailure: " + e); }
    }
}
