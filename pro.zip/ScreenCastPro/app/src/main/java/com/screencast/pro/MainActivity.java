package com.screencast.pro;

import android.Manifest;
import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.screencast.pro.databinding.ActivityMainBinding;
import com.screencast.pro.model.StreamConfig;
import com.screencast.pro.utils.NetworkUtils;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_PERMISSIONS = 100;
    private static final String[] REQUIRED_PERMISSIONS = {
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.POST_NOTIFICATIONS,
    };

    private ActivityMainBinding binding;
    private MediaProjectionManager projectionManager;

    // Service binding
    private RecordingService recordingService;
    private boolean serviceBound = false;

    // State
    private boolean isStreaming = false;
    private String  streamUrl   = null;
    private long    streamStartTime = 0;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private StreamConfig config = StreamConfig.defaultConfig();

    // Pulse animation
    private ValueAnimator pulseAnimator;

    // ── Activity result launchers ─────────────────────────────────────────────

    private final ActivityResultLauncher<Intent> projectionLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                startStreamingService(result.getResultCode(), result.getData());
            } else {
                showToast("Screen capture permission denied");
            }
        });

    // ── ServiceConnection ─────────────────────────────────────────────────────

    private final ServiceConnection serviceConnection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder binder) {
            RecordingService.LocalBinder lb = (RecordingService.LocalBinder) binder;
            recordingService = lb.getService();
            serviceBound = true;
            recordingService.setListener(serviceListener);
            isStreaming = recordingService.isStreaming();
            updateUI();
        }
        @Override public void onServiceDisconnected(ComponentName name) {
            serviceBound = false;
            recordingService = null;
        }
    };

    // ── Service listener ──────────────────────────────────────────────────────

    private final RecordingService.ServiceListener serviceListener = new RecordingService.ServiceListener() {
        @Override public void onStreamingStarted(String url) {
            streamUrl = url;
            isStreaming = true;
            streamStartTime = System.currentTimeMillis();
            runOnUiThread(() -> {
                updateUI();
                startPulseAnimation();
                startDurationTimer();
                binding.tvStreamUrl.setText(url);
                animateIn(binding.cardStreamUrl);
            });
        }
        @Override public void onStreamingStopped() {
            isStreaming = false;
            streamUrl = null;
            runOnUiThread(() -> {
                updateUI();
                stopPulseAnimation();
                stopDurationTimer();
                animateOut(binding.cardStreamUrl);
            });
        }
        @Override public void onViewerCountChanged(int count) {
            runOnUiThread(() -> binding.tvViewers.setText(String.valueOf(count)));
        }
        @Override public void onStats(long frames, int bps) {
            runOnUiThread(() -> {
                binding.tvFrames.setText(String.valueOf(frames));
                String bitrateStr = bps >= 1_000_000
                    ? String.format("%.1f Mbps", bps / 1_000_000f)
                    : String.format("%d Kbps", bps / 1000);
                binding.tvBitrate.setText(bitrateStr);
            });
        }
        @Override public void onError(String msg) {
            runOnUiThread(() -> showToast("Error: " + msg));
        }
    };

    // ── Duration timer ────────────────────────────────────────────────────────

    private final Runnable durationRunnable = new Runnable() {
        @Override public void run() {
            if (!isStreaming) return;
            long elapsed = System.currentTimeMillis() - streamStartTime;
            long s = elapsed / 1000;
            binding.tvDuration.setText(String.format("%02d:%02d:%02d", s/3600, (s%3600)/60, s%60));
            handler.postDelayed(this, 1000);
        }
    };

    private void startDurationTimer()  { handler.post(durationRunnable); }
    private void stopDurationTimer()   { handler.removeCallbacks(durationRunnable); binding.tvDuration.setText("00:00:00"); }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Edge-to-edge
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                             WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

        projectionManager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);

        setupUI();
        bindToService();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateNetworkInfo();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
        if (pulseAnimator != null) pulseAnimator.cancel();
        if (serviceBound) {
            unbindService(serviceConnection);
            serviceBound = false;
        }
    }

    // ── UI Setup ──────────────────────────────────────────────────────────────

    private void setupUI() {
        // Record / Stop button
        binding.btnRecord.setOnClickListener(v -> {
            if (isStreaming) {
                stopStreaming();
            } else {
                checkPermissionsAndStart();
            }
        });

        // Quality chips
        binding.chipHigh.setOnClickListener(v -> {
            config = StreamConfig.highQuality();
            highlightChip(0);
        });
        binding.chipMedium.setOnClickListener(v -> {
            config = StreamConfig.defaultConfig();
            highlightChip(1);
        });
        binding.chipLow.setOnClickListener(v -> {
            config = StreamConfig.lowLatency();
            highlightChip(2);
        });
        highlightChip(1); // Default = medium

        // URL copy button
        binding.btnCopyUrl.setOnClickListener(v -> {
            if (streamUrl != null) {
                ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("Stream URL", streamUrl));
                showToast("URL copied!");
            }
        });

        // Open in browser
        binding.btnOpenBrowser.setOnClickListener(v -> {
            if (streamUrl != null) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(streamUrl)));
            }
        });

        // Share URL
        binding.btnShare.setOnClickListener(v -> {
            if (streamUrl != null) {
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                share.putExtra(Intent.EXTRA_TEXT, "Watch my screen live: " + streamUrl);
                startActivity(Intent.createChooser(share, "Share Stream URL"));
            }
        });

        // Initial state
        binding.cardStreamUrl.setAlpha(0f);
        binding.cardStreamUrl.setVisibility(View.INVISIBLE);
        updateNetworkInfo();
    }

    private void highlightChip(int selected) {
        int accent  = 0xFF00F5C4;
        int inactive = 0xFF1A1A2E;
        binding.chipHigh.setBackgroundColor   (selected == 0 ? accent : inactive);
        binding.chipMedium.setBackgroundColor (selected == 1 ? accent : inactive);
        binding.chipLow.setBackgroundColor    (selected == 2 ? accent : inactive);
        int white = 0xFFFFFFFF;
        int dark  = 0xFF060608;
        binding.chipHigh.setTextColor   (selected == 0 ? dark : white);
        binding.chipMedium.setTextColor (selected == 1 ? dark : white);
        binding.chipLow.setTextColor    (selected == 2 ? dark : white);
    }

    private void updateNetworkInfo() {
        String ip = NetworkUtils.getLocalIpAddress();
        binding.tvDeviceIp.setText("📡 " + ip + ":" + SignalingServer.PORT);
    }

    private void updateUI() {
        if (isStreaming) {
            binding.btnRecord.setText("⬛  Stop Stream");
            binding.btnRecord.setBackgroundColor(0xFFFF3B5C);
            binding.tvStatus.setText("🔴  LIVE");
            binding.tvStatus.setTextColor(0xFFFF3B5C);
        } else {
            binding.btnRecord.setText("▶  Start Stream");
            binding.btnRecord.setBackgroundColor(0xFF00F5C4);
            binding.tvStatus.setText("⚪  READY");
            binding.tvStatus.setTextColor(0xFF888888);
            binding.tvViewers.setText("0");
            binding.tvFrames.setText("0");
            binding.tvBitrate.setText("—");
        }
    }

    // ── Animations ────────────────────────────────────────────────────────────

    private void startPulseAnimation() {
        if (pulseAnimator != null && pulseAnimator.isRunning()) return;
        pulseAnimator = ValueAnimator.ofFloat(1f, 1.06f, 1f);
        pulseAnimator.setDuration(900);
        pulseAnimator.setRepeatCount(ValueAnimator.INFINITE);
        pulseAnimator.setInterpolator(new DecelerateInterpolator());
        pulseAnimator.addUpdateListener(a -> {
            float s = (float) a.getAnimatedValue();
            binding.btnRecord.setScaleX(s);
            binding.btnRecord.setScaleY(s);
        });
        pulseAnimator.start();
    }

    private void stopPulseAnimation() {
        if (pulseAnimator != null) pulseAnimator.cancel();
        binding.btnRecord.setScaleX(1f);
        binding.btnRecord.setScaleY(1f);
    }

    private void animateIn(View v) {
        v.setVisibility(View.VISIBLE);
        v.animate().alpha(1f).translationY(0).setDuration(300)
            .setInterpolator(new DecelerateInterpolator()).start();
    }

    private void animateOut(View v) {
        v.animate().alpha(0f).translationY(20).setDuration(200)
            .setInterpolator(new DecelerateInterpolator())
            .withEndAction(() -> v.setVisibility(View.INVISIBLE)).start();
    }

    // ── Permissions + Service ─────────────────────────────────────────────────

    private void checkPermissionsAndStart() {
        List<String> missing = new ArrayList<>();
        for (String p : REQUIRED_PERMISSIONS) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED)
                missing.add(p);
        }
        if (missing.isEmpty()) {
            requestScreenCapture();
        } else {
            ActivityCompat.requestPermissions(this, missing.toArray(new String[0]), REQ_PERMISSIONS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, @NonNull String[] perms, @NonNull int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
        if (req == REQ_PERMISSIONS) {
            boolean allGranted = true;
            for (int r : results) if (r != PackageManager.PERMISSION_GRANTED) { allGranted = false; break; }
            if (allGranted) requestScreenCapture();
            else showToast("Permissions required for streaming");
        }
    }

    private void requestScreenCapture() {
        projectionLauncher.launch(projectionManager.createScreenCaptureIntent());
    }

    private void startStreamingService(int resultCode, Intent resultData) {
        Intent intent = new Intent(this, RecordingService.class);
        intent.putExtra(RecordingService.EXTRA_RESULT_CODE, resultCode);
        intent.putExtra(RecordingService.EXTRA_RESULT_DATA, resultData);
        startForegroundService(intent);
        bindToService();
    }

    private void stopStreaming() {
        if (recordingService != null) recordingService.stopStreaming();
        else {
            stopService(new Intent(this, RecordingService.class));
        }
    }

    private void bindToService() {
        Intent intent = new Intent(this, RecordingService.class);
        bindService(intent, serviceConnection, BIND_AUTO_CREATE);
    }

    private void showToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
