#include "encoder.h"

#include <jni.h>
#include <android/log.h>
#include <android/native_window_jni.h>
#include <string>
#include <memory>
#include <unordered_map>
#include <mutex>

#define LOG_TAG "ScreenCast_Bridge"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// ─── Global state ─────────────────────────────────────────────────────────────

static std::unique_ptr<screencast::NativeEncoder> g_encoder;
static std::mutex g_mutex;

// Java callback references
static JavaVM* g_jvm = nullptr;
static jobject g_callback_obj = nullptr;
static jmethodID g_on_frame_method = nullptr;

// ─── JNI_OnLoad ───────────────────────────────────────────────────────────────

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* /*reserved*/) {
    g_jvm = vm;
    JNIEnv* env = nullptr;
    if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
        return JNI_ERR;
    }
    LOGI("JNI_OnLoad OK");
    return JNI_VERSION_1_6;
}

// ─── Helper ───────────────────────────────────────────────────────────────────

static JNIEnv* getEnv() {
    JNIEnv* env = nullptr;
    if (!g_jvm) return nullptr;
    jint res = g_jvm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6);
    if (res == JNI_EDETACHED) {
        JavaVMAttachArgs args{JNI_VERSION_1_6, "EncoderThread", nullptr};
        g_jvm->AttachCurrentThread(&env, &args);
    }
    return env;
}

// ─── JNI Bridge Functions ─────────────────────────────────────────────────────

extern "C" {

// com.screencast.pro.NativeEncoder.nativeInit(width, height, fps, bitrate, codec)
JNIEXPORT jboolean JNICALL
Java_com_screencast_pro_NativeEncoder_nativeInit(
    JNIEnv* env, jobject thiz,
    jint width, jint height, jint fps, jint bitrate, jstring jcodec,
    jobject callback)
{
    std::lock_guard<std::mutex> lock(g_mutex);

    if (g_encoder) {
        g_encoder->release();
        g_encoder.reset();
    }

    const char* codec_str = env->GetStringUTFChars(jcodec, nullptr);

    screencast::EncoderConfig cfg;
    cfg.width       = width;
    cfg.height      = height;
    cfg.fps         = fps;
    cfg.bitrate_bps = bitrate;
    cfg.mime        = codec_str;  // "video/avc" or "video/hevc"

    g_encoder = std::make_unique<screencast::NativeEncoder>(cfg);

    // Store Java callback for encoded frames
    if (callback) {
        if (g_callback_obj) {
            env->DeleteGlobalRef(g_callback_obj);
        }
        g_callback_obj = env->NewGlobalRef(callback);
        jclass cls = env->GetObjectClass(callback);
        g_on_frame_method = env->GetMethodID(cls, "onFrameEncoded", "([BJZ)V");
    }

    // Set up encoded frame callback
    g_encoder->setOnFrameEncoded([](const screencast::VideoFrame& frame) {
        JNIEnv* env = getEnv();
        if (!env || !g_callback_obj || !g_on_frame_method) return;

        jbyteArray arr = env->NewByteArray((jsize)frame.size);
        env->SetByteArrayRegion(arr, 0, (jsize)frame.size,
                                reinterpret_cast<const jbyte*>(frame.data));
        env->CallVoidMethod(g_callback_obj, g_on_frame_method,
                            arr, (jlong)frame.timestamp_us,
                            (jboolean)frame.is_keyframe);
        env->DeleteLocalRef(arr);
    });

    bool ok = g_encoder->init();
    env->ReleaseStringUTFChars(jcodec, codec_str);

    if (!ok) {
        g_encoder.reset();
        LOGE("Encoder init failed");
        return JNI_FALSE;
    }

    LOGI("Encoder init success %dx%d", width, height);
    return JNI_TRUE;
}

// Returns the ANativeWindow-backed Surface for MediaProjection
JNIEXPORT jobject JNICALL
Java_com_screencast_pro_NativeEncoder_nativeGetInputSurface(
    JNIEnv* env, jobject /*thiz*/)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_encoder) return nullptr;
    return g_encoder->getInputSurface(env);
}

JNIEXPORT void JNICALL
Java_com_screencast_pro_NativeEncoder_nativeSignalEOS(
    JNIEnv* /*env*/, jobject /*thiz*/)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_encoder) g_encoder->signalEndOfStream();
}

JNIEXPORT void JNICALL
Java_com_screencast_pro_NativeEncoder_nativeRelease(
    JNIEnv* /*env*/, jobject /*thiz*/)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_encoder) {
        g_encoder->release();
        g_encoder.reset();
    }
}

JNIEXPORT jlong JNICALL
Java_com_screencast_pro_NativeEncoder_nativeGetFramesEncoded(
    JNIEnv* /*env*/, jobject /*thiz*/)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    return g_encoder ? (jlong)g_encoder->getFramesEncoded() : 0L;
}

JNIEXPORT jint JNICALL
Java_com_screencast_pro_NativeEncoder_nativeGetCurrentBitrate(
    JNIEnv* /*env*/, jobject /*thiz*/)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    return g_encoder ? (jint)g_encoder->getCurrentBitrate() : 0;
}

} // extern "C"
