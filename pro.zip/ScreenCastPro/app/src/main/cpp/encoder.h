#pragma once

#include <cstdint>
#include <memory>
#include <functional>
#include <atomic>
#include <thread>
#include <queue>
#include <mutex>
#include <condition_variable>

extern "C" {
#include <media/NdkMediaCodec.h>
#include <media/NdkMediaFormat.h>
#include <media/NdkMediaError.h>
}

namespace screencast {

struct VideoFrame {
    uint8_t* data;
    size_t size;
    int64_t timestamp_us;
    bool is_keyframe;
};

struct EncoderConfig {
    int width        = 1080;
    int height       = 1920;
    int fps          = 60;
    int bitrate_bps  = 8'000'000;   // 8 Mbps default
    int i_frame_interval = 2;        // seconds
    const char* mime = "video/avc";  // H.264; switch to "video/hevc" for H.265
    int color_format = 0x7F420888;   // COLOR_FormatSurface (from MediaCodecInfo)
    int profile      = 8;            // AVCProfileHigh
    int level        = 0x200;        // AVCLevel51
};

struct AudioConfig {
    int sample_rate  = 44100;
    int channel_count = 1;
    int bitrate_bps  = 128'000;
};

class NativeEncoder {
public:
    using OnFrameEncoded = std::function<void(const VideoFrame&)>;

    explicit NativeEncoder(const EncoderConfig& cfg);
    ~NativeEncoder();

    bool init();
    void release();

    // Returns the input Surface that MediaProjection writes into
    jobject getInputSurface(JNIEnv* env);

    void setOnFrameEncoded(OnFrameEncoded cb) { on_frame_encoded_ = std::move(cb); }
    void signalEndOfStream();

    // Stats
    uint64_t getFramesEncoded() const { return frames_encoded_.load(); }
    uint64_t getBytesEncoded()  const { return bytes_encoded_.load(); }
    int getCurrentBitrate()     const;

private:
    void encoderLoop();
    void processOutputBuffers();

    EncoderConfig cfg_;
    AMediaCodec*  codec_      = nullptr;
    ANativeWindow* surface_   = nullptr;

    std::thread   encoder_thread_;
    std::atomic<bool> running_{false};
    std::atomic<bool> eos_requested_{false};

    OnFrameEncoded on_frame_encoded_;

    std::atomic<uint64_t> frames_encoded_{0};
    std::atomic<uint64_t> bytes_encoded_{0};

    // Bitrate estimation
    uint64_t bytes_last_sec_  = 0;
    int64_t  last_bps_time_   = 0;
    int      current_bps_     = 0;
};

class AudioCapture {
public:
    explicit AudioCapture(const AudioConfig& cfg);
    ~AudioCapture();

    bool start();
    void stop();

    void setOnPCMReady(std::function<void(const int16_t*, size_t)> cb) {
        on_pcm_ = std::move(cb);
    }

private:
    AudioConfig cfg_;
    std::function<void(const int16_t*, size_t)> on_pcm_;
    std::atomic<bool> running_{false};
    std::thread thread_;
};

} // namespace screencast
