# ScreenCast Pro 📱🔴

Modern Android screen recording & live streaming app with **WebRTC** — zero server needed.

## ✨ Features

| Feature | Detail |
|---------|--------|
| **Screen Capture** | MediaProjection API (Android 9+) |
| **Native Encoder** | C++20 + Android NDK MediaCodec (H.264 / H.265) |
| **Live Streaming** | WebRTC via `io.github.webrtc-sdk:android` |
| **Signaling** | Embedded HTTP + WebSocket server on **port 9339** |
| **Viewer UI** | Modern dark HTML page, auto-connects, shows FPS/bitrate |
| **Quality Presets** | 4K HEVC · 1080p H.264 · 720p Low Latency |
| **UI** | Material Design 3 · Glassmorphism · Dark theme · Animations |

## 🚀 Quick Start

### Requirements
- Android Studio Hedgehog (2023.1.1) or newer
- Android NDK 26+ installed
- CMake 3.22.1+
- Test device: **Android 9.0 (API 28)+**

### Build Steps

```bash
# 1. Clone / extract project
cd ScreenCastPro

# 2. Open in Android Studio
# File → Open → select this folder

# 3. Sync Gradle (it downloads all dependencies automatically)

# 4. Install NDK if missing:
#    Android Studio → SDK Manager → SDK Tools → NDK (Side by side) ✓

# 5. Run on device
# Make sure USB debugging is ON
```

### Streaming

1. Launch app → tap **▶ Start Stream**
2. Grant screen capture permission
3. App shows: `http://192.168.X.X:9339`
4. Open that URL in any browser (same WiFi network)
5. Watch your screen live via WebRTC!

## 📐 Architecture

```
┌────────────────────────────────────────────┐
│             MainActivity (UI)              │
│  Material 3 · Dark · Glassmorphism cards   │
└────────────┬───────────────────────────────┘
             │ binds
┌────────────▼───────────────────────────────┐
│         RecordingService (Foreground)       │
│  MediaProjection → ScreenCapturerAndroid   │
└────────┬──────────────────────┬────────────┘
         │                      │
┌────────▼──────────┐  ┌────────▼────────────┐
│  WebRTCManager    │  │   SignalingServer    │
│  PeerConnections  │  │  NanoHTTPD + WS     │
│  VideoTrack       │  │  Port 9339          │
│  AudioTrack       │  │  HTML viewer page   │
└────────┬──────────┘  └─────────────────────┘
         │ WebRTC ICE + SDP
┌────────▼──────────────────────────────────┐
│            Browser Viewer                  │
│  http://[device-ip]:9339                  │
│  WebRTC recvonly · FPS & bitrate stats    │
└────────────────────────────────────────────┘

Native Layer (C++20):
┌───────────────────────────────────────────┐
│  NativeEncoder (encoder.cpp)              │
│  AMediaCodec H.264/H.265 hardware encode │
│  Surface input → compressed NAL output   │
│  native_bridge.cpp → JNI bindings        │
└───────────────────────────────────────────┘
```

## 🔧 Configuration

Edit `StreamConfig.java`:

```java
// Ultra quality (H.265)
StreamConfig.highQuality()    // 1080p, 60fps, 12Mbps, HEVC

// Default balanced (H.264)
StreamConfig.defaultConfig()  // 1080p, 60fps, 8Mbps, AVC

// Low latency
StreamConfig.lowLatency()     // 720p, 30fps, 4Mbps, AVC
```

## 🌐 WebRTC Signaling Flow

```
Browser ──WS── SignalingServer (port 9339)
  │                   │
  │  1. offer SDP     │
  │ ──────────────>   │
  │                   │──> WebRTCManager.handleOffer()
  │                   │<── creates answer SDP
  │  2. answer SDP    │
  │ <──────────────   │
  │  3. ICE candidates (bidirectional)
  │ <─────────────>   │
  │                   │
  └──── WebRTC P2P stream ──────────────> Android device
```

## 📋 Permissions

| Permission | Use |
|-----------|-----|
| `FOREGROUND_SERVICE` | Background recording |
| `FOREGROUND_SERVICE_MEDIA_PROJECTION` | Screen capture |
| `RECORD_AUDIO` | Microphone capture |
| `INTERNET` | WebRTC + signaling server |
| `POST_NOTIFICATIONS` | Foreground service notification |
| `ACCESS_WIFI_STATE` | Display local IP address |

## 🗂 Project Structure

```
app/src/main/
├── cpp/
│   ├── CMakeLists.txt        # Native build config
│   ├── encoder.h/.cpp        # C++20 MediaCodec encoder
│   └── native_bridge.cpp     # JNI bridge
├── java/com/screencast/pro/
│   ├── MainActivity.java     # Modern Material 3 UI
│   ├── RecordingService.java # Foreground service
│   ├── WebRTCManager.java    # WebRTC peer connections
│   ├── SignalingServer.java  # NanoHTTPD HTTP+WS server
│   ├── NativeEncoder.java    # JNI wrapper
│   ├── model/
│   │   ├── StreamConfig.java # Quality presets
│   │   └── StreamStats.java  # Runtime stats
│   └── utils/
│       └── NetworkUtils.java # Local IP detection
└── res/
    ├── layout/activity_main.xml   # Glassmorphism dark UI
    ├── drawable/                  # Gradients, blobs, chips
    ├── anim/                      # Pulse animations
    └── values/                    # Colors, themes, strings
```

## 🔑 Key Dependencies

```gradle
implementation 'io.github.webrtc-sdk:android:125.6422.06.1'
implementation 'org.nanohttpd:nanohttpd:2.3.1'
implementation 'org.nanohttpd:nanohttpd-websockets:2.3.1'
implementation 'com.google.android.material:material:1.12.0'
```

## 🛡 Security Notes

- The stream is accessible to **anyone on your LAN** at port 9339
- For public internet streaming, set up a TURN server and expose the port
- Consider adding a PIN/token for production use

---

Built with ❤️ · C++20 NDK · WebRTC · Material Design 3
